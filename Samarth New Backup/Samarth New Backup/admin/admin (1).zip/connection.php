<?php
// Enter your Host, username, password, database below.
// I left password empty because i do not set password on localhost.
// $connect = mysqli_connect('localhost', 'root', '', 'dynamic-career');
    // Create a database connection
   $servername = "localhost"; // Replace with your server name
    $username = "root"; // Replace with your database username
    $password = ""; // Replace with your database password
    $dbname = "dynamic-career"; // Replace with your database name


    $conn = new mysqli($servername, $username, $password, $dbname);
if ($conn) {
	// echo "Connection Successfully";
}
else{
	echo "Sorry Some Mistakes is";
}
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>